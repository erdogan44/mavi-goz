import json, io, os, base64, threading, time
import flet as ft
import pandas as pd
from PIL import Image
import warnings
import httpx # Tarayıcı dostu bağlantı

warnings.filterwarnings('ignore', category=DeprecationWarning)

# --- AYARLAR ---
SETTINGS_FILE = "mavi_goz_ayarlar.json"
VARSAYILAN_TALIMAT = "Görseldeki öğrenci yazılarını oku ve cevap anahtarına göre puanla."

def ayarları_yukle():
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except: pass
    return {"anahtar": "", "talimat": VARSAYILAN_TALIMAT}

def main(page: ft.Page):
    page.title = "MAVi-GÖZ Web (Pure Edition)"
    page.theme_mode = ft.ThemeMode.LIGHT
    
    API_KEY = ""
    anahtar_depo, ogrenci_depo = {}, {}
    kayitli_ayarlar = ayarları_yukle()

    # --- UI ELEMANLARI ---
    anahtar_metin = ft.TextField(label="Cevap Anahtarı", value=kayitli_ayarlar["anahtar"], multiline=True, expand=True)
    talimat_metin = ft.TextField(label="Talimat", value=kayitli_ayarlar["talimat"], multiline=True, expand=True)
    durum_label = ft.Text("Hazır Hocam.", weight="bold")
    progress_bar = ft.ProgressBar(visible=False)
    anahtar_galeri = ft.Row(wrap=True, scroll="auto")
    ogrenci_galeri = ft.Row(wrap=True, scroll="auto")

    # --- GEMINI BAĞLANTISI (KÜTÜPHANESİZ) ---
    async def gemi_analiz(image_bytes, prompt):
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={API_KEY}"
        b64_image = base64.b64encode(image_bytes).decode('utf-8')
        
        payload = {
            "contents": [{
                "parts": [
                    {"text": prompt},
                    {"inline_data": {"mime_type": "image/jpeg", "data": b64_image}}
                ]
            }]
        }
        
        async with httpx.AsyncClient() as client:
            res = await client.post(url, json=payload, timeout=60.0)
            return res.json()['candidates'][0]['content']['parts'][0]['text']

    # --- DOSYA SEÇME ---
    def dosya_sonuc(e: ft.FilePickerResultEvent):
        if not e.files: return
        depo = anahtar_depo if e.control.id == "a" else ogrenci_depo
        galeri = anahtar_galeri if e.control.id == "a" else ogrenci_galeri
        
        for f in e.files:
            if f.bytes:
                depo[f.name] = f.bytes
                galeri.controls.append(ft.Image(src_base64=base64.b64encode(f.bytes).decode(), width=80, height=100))
        page.update()

    a_picker = ft.FilePicker(on_result=dosya_sonuc); a_picker.id = "a"
    o_picker = ft.FilePicker(on_result=dosya_sonuc); o_picker.id = "o"
    page.overlay.extend([a_picker, o_picker])

    # --- ANALİZ ---
    async def analiz_tetikle(e):
        if not API_KEY: 
            durum_label.value = "Lütfen önce giriş yapın!"; page.update(); return
        
        progress_bar.visible = True; durum_label.value = "İşleniyor..."; page.update()
        
        for n, d in ogrenci_depo.items():
            try:
                p = f"{talimat_metin.value}\nAnahtar: {anahtar_metin.value}\nJSON formatında yanıtla."
                sonuc = await gemi_analiz(d, p)
                print(f"{n} bitti: {sonuc}")
            except Exception as ex:
                print(f"Hata: {ex}")
        
        durum_label.value = "Tamamlandı! ✅"; progress_bar.visible = False; page.update()

    # --- BASİT GİRİŞ ---
    user_id = ft.TextField(label="Öğretmen ID", width=150)
    user_api = ft.TextField(label="Gemini API Key", password=True, width=250)
    
    def giris_yap(e):
        nonlocal API_KEY
        API_KEY = user_api.value
        if API_KEY:
            ana_panel.disabled = False
            durum_label.value = "Bağlantı Kuruldu! ✅"
            page.update()

    ana_panel = ft.Column([
        ft.Row([
            ft.ElevatedButton("Anahtar Seç", on_click=lambda _: a_picker.pick_files(allow_multiple=True)),
            ft.ElevatedButton("Sınavları Seç", on_click=lambda _: o_picker.pick_files(allow_multiple=True)),
        ]),
        anahtar_galeri, ogrenci_galeri,
        anahtar_metin, talimat_metin,
        progress_bar, durum_label,
        ft.FilledButton("ANALİZİ BAŞLAT", on_click=analiz_tetikle)
    ], disabled=True, expand=True)

    page.add(
        ft.Row([user_id, user_api, ft.ElevatedButton("Giriş", on_click=giris_yap)]),
        ft.Divider(),
        ana_panel
    )

ft.app(target=main)